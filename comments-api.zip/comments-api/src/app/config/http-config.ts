export const httpConfig = {
  url: 'http://134.122.72.178:3000'
};
